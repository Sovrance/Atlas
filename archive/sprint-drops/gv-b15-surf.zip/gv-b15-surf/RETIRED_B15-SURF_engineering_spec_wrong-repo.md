# B15-SURF — Engineering Specification
## Integrating the Surfaceology / Positivity-Bootstrap Recommendations into Global-variables

| Field | Value |
|---|---|
| Document ID | GV-ENG-B15-SURF-001 |
| Status | DRAFT — pending Erick sign-off on §9 open items before any claims-table.md contact |
| Sprint ID | B15-SURF (B* prefix per program naming rule; M* reserved for the mathematics ledger) |
| Date | 2026-09-23 |
| Owner | Erick L. Gonzalez (sole push/auth) |
| Author | Rosy 🌹 (research & engineering collaborator) |
| Executor | Coding agent (Codex/Cursor) working in `ErickLGonzalez/Global-variables` |
| Inputs | (1) *Surfaceology and Hidden Zeros: Discovery Heuristics for Constraint-Certified Physics* (deep-research report, 2026-09-21); (2) *Reverse-Engineering Tooling as a Blueprint for Observational Decompilation of Physics* (Ghidra report, PIR Foundation Package v2); (3) SPECIFICATION.md v1.0; (4) methodology conventions (§6 verdict vocabulary, E0–E4, certificate schema) |
| Supersedes | none |

---

## 0. Read this first (agent operating rules)

These rules are frozen for the sprint. Violating any of them is a sprint FAIL regardless of code quality.

1. **Reconcile before you build.** This spec was written without the live tree in front of the author. Every path below is a *target*; before creating any file, run WP0 (§3.0) and map each target to the repo's actual layout. Do not create parallel directory trees. If a target conflicts with an existing convention, follow the existing convention and record the mapping in `docs/sprints/B15-SURF/reconciliation.md`.
2. **Python stdlib only** in all pipeline and certification code. No numpy/sympy/scipy in the certified path. `fractions.Fraction` is the only arithmetic permitted where a certificate is emitted. Floating point is allowed only in exploratory/diagnostic scripts that are clearly named `*_explore.py` and never feed a certificate.
3. **Verdict vocabulary is locked.** Only: `CONDITIONAL(X)`, `OBSERVATIONALLY_EQUIVALENT`, `NONIDENTIFIABLE`, `APPARATUS_LIMITED`, `REPRESENTATION_DEPENDENT`, `ENTAILMENT_REFUTED`, `ENTAILMENT_PROVED`, `ENTAILMENT_UNREFUTED`, plus the pipeline outcomes `FORCED` / `PERMITTED` / `REJECTED`. Do not invent labels. If a result does not fit, emit `NONIDENTIFIABLE(cause)` with the cause string and file an open item.
4. **Every certificate** carries the mandatory fields `calibration_route` and `m_layer_stipulations`, plus the fields added in §5. Every analyzer pass carries `soundness: SOUND | HEURISTIC`. `HEURISTIC` passes must emit a located `warning` entry.
5. **Uncertified ≠ pass.** A benchmark whose certificate fails to validate against its schema is a FAIL, not a warning.
6. **No atlas contact.** B15-SURF results are mathematics-ledger / benchmark entries. They do **not** modify any restraint-matrix cell in `claims-table.md`. The hidden-zero equivalences are theory-internal identities, not measurements; they cannot be FUNDAMENTAL-REAL at E0–E2 in the atlas sense (see §6).
7. **Symmetric PASS/FAIL, pre-registered.** Thresholds are written into `prereg-002` (§7) *before* the first certified run. A FAIL is filed as `REJECTED` with a witness, never silently repaired. Errata go in `docs/errata/` with the next sequential edit number.
8. **Commit cadence.** Commit at the end of every WP task (not every WP), with the commit message prefix `B15-SURF:`. Erick pushes; you do not. Package the sprint as `B15-SURF_part1.zip` (live tree, < 25 MB) and `B15-SURF_partN.zip` for archives if needed.
9. **Cite primary sources for every physics constant, formula, or index convention you transcribe.** Record the arXiv ID, section, and equation number in the prereg. Where this spec says "record from source," it means the exact expression must be copied from the paper, not reconstructed from memory.

---

## 1. Scope

**Goal.** Turn the two research reports into a certified, pre-registered benchmark sprint that (a) anchors the program's positivity machinery on the mature bootstrap precedent, (b) reproduces the surfaceology hidden-zero results in exact arithmetic as a ground-truth benchmark, and (c) tests the program's own rival-generator / canonicalization machinery on a case where the correct equivalence-class answer is known in advance.

**In scope (this sprint):**
- WP0 — Repo reconciliation and headless CI entrypoint (Ghidra report Stage 1 items 1–3, completed or verified complete).
- WP1 — Positivity certification benchmark **B15-POS**: reproduce one published EFT-hedron bound with a primal witness + dual certificate in exact rational arithmetic.
- WP2 — Surfaceology reproduction benchmark **B15-ZERO**: Tr(φ³) 5- and 6-point tree amplitudes by two independent routes; hidden zeros; 2-split near zeros; δ-shift to NLSM.
- WP3 — Blind grammar-identification benchmark **B15-GID**: classify {Tr(φ³), NLSM, YM-scaffolded} from zero-and-factorization fingerprints only, and recover δ; pre-registered for *both* outcomes.
- WP4 — Design note (no pipeline code) on a constraint-manifest internal representation for one toy sector of 𝕽.

**Out of scope (backlog, §10):** ML/symbolic-regression conjecture generation; loop-level surfaceology; gravity/fermion extensions; any MnemesisOS transfer.

**Non-goals stated for the record.** Nothing in this sprint claims to derive a constant of nature, discover a new law, or promote an atlas cell. The sprint tests *tooling and epistemics* against a domain where ground truth exists.

---

## 2. Design principles imported (with analogy strength)

The coding agent does not need to re-derive these; they justify the WP structure.

| ID | Principle | Strength | Where it lands |
|---|---|---|---|
| P1 | Representation redundancy is a wrong-representation signal | Strong | B15-GID redundancy metric (§3.3) |
| P2 | Prefer representations where hard constraints are structural, not checked | Strong | WP4 design note |
| P3 | Zeros / poles / factorization are basis-independent fingerprints | Strong (classification), Moderate (discovery) | B15-ZERO, B15-GID fingerprint schema |
| P4 | Base grammar + simple deformation family | Moderate | Grammar database entries (§3.3) |
| P6 | Positivity / convexity as certifiable organizing constraint | Strong | B15-POS |
| P8 | Quotient by representation redundancy before comparing | Strong (concept), Moderate (ops) | M1 canonicalization hook in B15-GID |
| P10 | Generate large exact datasets before hypothesizing | Strong | Dataset generators in every WP |
| A4 (Ghidra) | Monotonic, provenance-annotated candidate store; defer selection | Strong | B15-GID candidate forest output |
| A7 (Ghidra) | SAT-witness / UNSAT-certificate structure | Strong | B15-POS dual certificates |

Analogies tagged Moderate are treated as hypotheses under test, not design assumptions.

---

## 3. Work packages

### 3.0 WP0 — Reconciliation and CI entrypoint

**Purpose.** Confirm the Ghidra Stage 1 prerequisites are actually in the tree, and establish one headless entrypoint so `v0.7-frozen`-style preregistration is enforceable.

**Tasks.**
- WP0.1 Inventory. Produce `docs/sprints/B15-SURF/reconciliation.md` listing: the actual location of `SPECIFICATION.md`, `claims-table.md`, `schemas/`, `tests/test_b*.py`, the M1 canonicalization engine, the M2 generator engine, the B12-RGRC rival-generator harness, and the exact-Fraction Schur-pivot verifier (the "verifier standard" reused across B1/B2/B6/B7/B10). Record the import path and public function signatures of each.
- WP0.2 Verify prerequisites. Check that (a) every existing certificate JSON carries `soundness`, (b) every equivalence output reports `similarity`, `confidence`, and `correlator` as separate fields. If either is missing anywhere, fix it *first* under a `B15-SURF: WP0 prerequisite` commit and file an erratum noting which certificates were retrofitted.
- WP0.3 Headless entrypoint. Add `tools/run_all_certified.py` (stdlib only) that: discovers all `tests/test_b*.py`; runs each; collects every certificate JSON it emits; validates each against its schema in `schemas/`; writes `artifacts/ci/summary.json` with per-benchmark PASS/FAIL and certificate hash; exits non-zero if any benchmark fails, any certificate fails validation, or any certificate hash differs from the committed baseline in `artifacts/ci/baseline.json` (unless `--rebaseline` is passed, which must be a separate, explicitly named commit).
- WP0.4 Determinism. Every generator takes an explicit `seed` argument; certificates record `seed`, Python version, and a hash of the generator source file.

**Exit criterion.** `python3 tools/run_all_certified.py` is green on the pre-B15 tree with 22/22 suites and a committed baseline.

---

### 3.1 WP1 — B15-POS: Positivity certification against a published bound

**Purpose.** The program's exact-PSD machinery has never been checked against an externally published positivity bound. If it cannot reproduce a *known* EFT-hedron bound with certificates, its novel PERMITTED/EXCLUDED claims are not trustworthy. This is Stage 0 of the surfaceology report and is the gate for everything else.

**Target bound.** The 2→2 single-scalar EFT forward-limit bounds from Arkani-Hamed, Huang, Huang, *The EFT-Hedron*, arXiv:2012.15849. The agent selects the *lowest-order* nontrivial bound that involves at least one two-sided inequality (i.e. not merely a single "coefficient ≥ 0"), copies the exact statement (equation number, coefficient normalization, and Mandelstam conventions) into `prereg-002` §POS, and does not proceed until Erick confirms the target in §9-OI-1.

**Tasks.**
- WP1.1 `pipelines/b15_pos/moment_problem.py`: construct the finite-truncation moment/Hankel matrices for the chosen bound in `Fraction` arithmetic, using the dispersive representation from the paper (transcribed, cited).
- WP1.2 Primal witness. For a point pre-registered as *inside* the allowed region: produce an explicit PSD certificate via the existing Schur-pivot verifier (all pivots ≥ 0, listed). Verdict: `PERMITTED` with witness.
- WP1.3 Dual certificate. For a point pre-registered as *outside*: produce an exact negative Schur pivot (UNSAT-core analogue) **and** an explicit dual functional — a rational vector `y` with `y ≥ 0` in the appropriate cone such that `⟨y, constraints⟩` yields a contradiction. Both must be present. Verdict: `REJECTED` with witness.
- WP1.4 Boundary bracket. Bisect in exact arithmetic along one pre-registered ray to bracket the published bound value to a pre-registered width (see §7). Report `[inner feasible, outer infeasible]` exactly as B1 does.
- WP1.5 Independent re-verification script `tools/verify_certificate.py` that checks a B15-POS certificate from its contents alone (re-computes pivots and re-evaluates the dual functional) without importing the pipeline. This is Ghidra recommendation 8.
- WP1.6 Negative control. Corrupt one Hankel entry by a pre-registered rational amount and confirm the pipeline flips the verdict with a witness.

**Pass criteria (frozen in prereg).** Bracket contains the published value; width ≤ registered threshold; `verify_certificate.py` accepts every emitted certificate; negative control flips. Any miss → `REJECTED`, erratum, and stop: WP2–WP3 may proceed but their certificates are marked `CONDITIONAL(B15-POS-unverified)`.

**Soundness tags.** WP1.1–1.5 are `SOUND` (exact). Any truncation-order choice is a `HEURISTIC` step and must carry a `warning` naming the truncation.

---

### 3.2 WP2 — B15-ZERO: Surfaceology reproduction in exact arithmetic

**Purpose.** Establish a ground-truth dataset where the answer is known, the zeros are known, and the equivalence class (Tr(φ³) ~ NLSM ~ YM up to δ) is known. This dataset is the input to B15-GID.

**Kinematic conventions (record from source).** Planar variables `X_{i,j} = (p_i + … + p_{j-1})²` and mesh variables `c_{i,j} = X_{i,j} + X_{i+1,j+1} − X_{i,j+1} − X_{i+1,j}`, following arXiv:2312.16282 §2. The agent transcribes the index ranges and the exact statement of the hidden-zero locus (the "maximal rectangle / causal diamond" condition) into `prereg-002` §ZERO with equation numbers. Do not reconstruct the index set from memory.

**Tasks.**
- WP2.1 Route A — planar Feynman sum. `pipelines/b15_zero/triangulations.py`: enumerate triangulations of the n-gon (Catalan count checked: 5 for n=5, 14 for n=6); amplitude `A_n = Σ_T ∏_{chords∈T} 1/X_chord` in `Fraction` over rational kinematic points.
- WP2.2 Route B — independent route. Implement the tree-level recursion from factorization (residue on each `X=0` pole equals product of lower-point amplitudes), building `A_5` and `A_6` from `A_4 = 1/X_{1,3} + 1/X_{2,4}` and `A_3 = 1`. Routes A and B must agree exactly on ≥ 200 pre-registered random rational points per multiplicity. Disagreement anywhere → `REJECTED`, stop.
- WP2.3 Optional Route C (only if WP2.1–2.2 finish early): evaluate the ABHY associahedron canonical form (arXiv:1711.09102) for n=5 via the `X`-space realization and confirm agreement. Tag `HEURISTIC` if any sign/orientation convention is not fully pinned by the source.
- WP2.4 Hidden zeros. For every admissible split registered in the prereg, impose the zero locus on rational kinematics (solve the linear conditions exactly), evaluate `A_n` by Routes A and B, and confirm `A_n = 0` exactly. Also confirm the *negative* control: impose the same number of *random* linear conditions and confirm `A_n ≠ 0` generically (at ≥ 95% of sampled points, threshold registered).
- WP2.5 2-split near zeros. Following arXiv:2405.09608 (transcribe the split statement and the definition of the single relaxed variable `c_⋆`), relax exactly one mesh variable off the zero locus and verify the amplitude factorizes into the two lower currents specified by the paper, exactly, on ≥ 50 registered points.
- WP2.6 δ-shift to NLSM. Implement `X_{e,e} → X_{e,e} + δ`, `X_{o,o} → X_{o,o} − δ` on the Tr(φ³) amplitude and take the limit/scaling prescription **exactly as stated in arXiv:2401.05483** (the agent records the prefactor and limit in prereg §ZERO-δ; this spec deliberately does not state it). Compare against independently computed NLSM flavor-ordered amplitudes at 4 and 6 points obtained from the NLSM Feynman rules as given in the same paper or its cited source. Exact agreement required.
- WP2.7 Dataset export. `data/b15/zero_dataset_v1.json`: for each theory in {Tr(φ³), NLSM(δ)}, per multiplicity, a list of `(kinematic_point, amplitude_value, on_zero_locus: bool, split_id | null)` in exact rationals, plus the generator seed. YM-scaffolded points are included **only** if WP2.8 is completed.
- WP2.8 (stretch) YM-scaffolded amplitudes per arXiv:2401.00041 at the lowest multiplicity the paper gives in closed form. If not completed, B15-GID runs on two classes and the prereg records the reduced scope in advance.

**Soundness tags.** WP2.1, 2.2, 2.4, 2.5, 2.6 `SOUND`. WP2.3 and 2.8 `HEURISTIC` until conventions are pinned.

**Evidence level.** All B15-ZERO results are exact identities: warrant E0 on the mathematics ledger. They are not atlas facts (§6).

---

### 3.3 WP3 — B15-GID: Blind grammar identification from fingerprints

**Purpose.** This is the real test of the program's rival-generator idea (B12-RGRC) and canonicalization engine (M1) on a case with known ground truth. It is pre-registered for two outcomes and **both are reported as successes of the epistemics**, not of the classifier.

**Pipeline contract.** `pipelines/b15_gid/identify.py` receives *only* `data/b15/zero_dataset_v1.json` with the `theory` label stripped and δ hidden. It never imports the amplitude generators. It must output a **candidate forest** (Ghidra A4 pattern), not a single label:

```json
{
  "candidates": [
    {"grammar": "TrPhi3", "deformation": {"delta": "0"}, "provenance": ["zero-locus-match:split-1..k", "pole-set-match"], "similarity": "…", "confidence": "…", "correlator": "zero-fingerprint-v1", "soundness": "HEURISTIC", "warnings": [...]},
    {"grammar": "NLSM", "deformation": {"delta": "…"}, ...}
  ],
  "selected": null | {"grammar": ..., "basis": "…"},
  "verdict": "…",
  "redundancy_metric": "…"
}
```

**Fingerprint schema (`schemas/fingerprint_v1.json`).** Per amplitude sample set: the exact set of simple poles detected (which `X_{i,j}` produce divergence under registered scaling), the set of zero loci detected (which registered splits annihilate the amplitude), the observed 2-split structure, and a **redundancy metric** = (number of terms in the naive triangulation representation) / (number of independent fingerprint constraints). P1 predicts this metric is large and is a pointer to a compressed representation; record it, do not act on it this sprint.

**Grammar database (`data/grammars/known_grammars_v1.json`).** Entries for Tr(φ³), NLSM, YM-scaffolded: expected pole sets, expected zero loci, deformation parameters and their allowed range, and a two-tier hash per Ghidra B2 (full hash = fingerprint invariants insensitive to δ; specific hash = includes δ). Sources cited per entry.

**Tasks.**
- WP3.1 Build fingerprints from the dataset (`SOUND` for pole/zero detection since arithmetic is exact; `HEURISTIC` for any tolerance on "generically nonzero").
- WP3.2 Hook M1 canonicalization: quotient fingerprints by the registered relabeling group (cyclic + reflection of the color ordering) before matching.
- WP3.3 Hook B12-RGRC: treat each grammar in the database as a rival generator; compute similarity and confidence separately with correlator named.
- WP3.4 δ recovery: for candidates with a deformation parameter, solve for δ exactly from the shifted-pole positions; report the recovered rational or `NONIDENTIFIABLE(delta-underdetermined)`.
- WP3.5 Held-out test: fingerprints are built from n ≤ 6; the classifier is then applied to n = 8 samples generated by WP2 generators (add n=8 generation to WP2.7 — Catalan(6)=132 triangulations, still trivial in exact arithmetic).

**Pre-registered outcomes (both PASS for the sprint):**
- **Outcome A — separable.** Fingerprints distinguish the classes and recover δ on held-out n=8 with similarity ≥ registered threshold and confidence ≥ registered threshold. Verdict on the ledger: `ENTAILMENT_PROVED` for "zero-and-pole fingerprints separate these grammars at tree level, n≤8." 
- **Outcome B — not separable.** Fingerprints do *not* separate the classes because the theories share zeros by construction. Verdict: `OBSERVATIONALLY_EQUIVALENT([TrPhi3, NLSM, YM] mod δ-shift)` with `selected: null`, and a ledger note that fingerprint-only identification is fundamentally limited for deformation-related grammars. This outcome is the more important epistemic lesson and must not be reframed as a classifier failure.
- **Anything else** (e.g. partial separation, instability across seeds) → `NONIDENTIFIABLE(cause)` with cause string and an open item.

**Falsifier registered.** If the classifier separates classes at n≤6 but fails at n=8, the fingerprint schema is over-fit to low multiplicity; file `REJECTED` against fingerprint_v1 and do not ship it.

---

### 3.4 WP4 — Design note: constraint-manifest representation (no pipeline code)

**Purpose.** P2 is the deepest import and the least ready. This WP produces a design note only.

**Deliverable.** `docs/design/constraint-manifest-representation-v0.md` (≤ 3 pages) answering: for the toy sector of 𝕽 used in B10 (CV Gaussian channels) or B12-b (quantum layer), which of Pos / Uni / Cau is currently *checked* by a pipeline pass, and is there a known coordinate choice (analogue of u-variables, symplectic normal form, Choi-parameterization, etc.) under which that constraint holds identically? For each candidate coordinate choice: what it makes automatic, what it hides, and what a Stage-3 benchmark would look like with a pre-registered threshold ("turns ≥ 1 previously-checked constraint into an identity, verified on the B15-ZERO / B10 datasets").

**Rule.** No claims, no code beyond throwaway `*_explore.py`. Flag for Erick's decision whether to open B16 on it.

---

## 4. Repository layout (targets — reconcile in WP0)

```
pipelines/b15_pos/            moment_problem.py, certify.py
pipelines/b15_zero/           triangulations.py, recursion.py, zeros.py, splits.py, delta_shift.py, nlsm_feynman.py
pipelines/b15_gid/            fingerprint.py, identify.py
tools/run_all_certified.py    headless CI entrypoint (WP0)
tools/verify_certificate.py   standalone certificate re-verifier (WP1.5)
schemas/certificate_v2.json   extends v1 with §5 fields
schemas/fingerprint_v1.json
schemas/candidate_forest_v1.json
data/b15/zero_dataset_v1.json
data/grammars/known_grammars_v1.json
tests/test_b15_pos.py
tests/test_b15_zero.py
tests/test_b15_gid.py
artifacts/ci/{baseline.json, summary.json}
artifacts/certificates/b15_*.json
docs/sprints/B15-SURF/{reconciliation.md, prereg-002.md, sprint-report.md}
docs/design/constraint-manifest-representation-v0.md
docs/errata/edit-0NN-*.md
```

If the repo keeps pipelines under a different root (e.g. `src/` or per-benchmark folders), mirror that root and document the mapping.

---

## 5. Certificate schema extension (`certificate_v2`)

Retain every v1 field (including mandatory `calibration_route` and `m_layer_stipulations`). Add:

| Field | Type | Required | Notes |
|---|---|---|---|
| `soundness` | `SOUND \| HEURISTIC` | yes | per pass; a certificate composed of passes carries the weakest |
| `warnings` | list of `{location, text}` | yes if HEURISTIC | located, Ghidra A5 |
| `ground_truth_route` | string \| null | yes | e.g. `"planar-feynman-sum"`, `"published-bound:arXiv:2012.15849 eq.N"`, `null` when no ground truth exists — this field is the honesty marker for the ground-truth disanalogy |
| `witness` | object | yes for PERMITTED/REJECTED | pivots list, or dual functional `y`, or split factorization |
| `dual_certificate` | object \| null | yes for B15-POS REJECTED | rational vector + evaluation showing contradiction |
| `similarity`, `confidence`, `correlator` | Fraction-string, Fraction-string, string | yes for equivalence outputs | separate, never merged |
| `evidence_level` | `E0..E4` | yes | warrant axis |
| `pir_level` | `L*` | yes | representation axis, orthogonal to evidence_level |
| `prereg_ref` | string | yes | `prereg-002#section` |
| `falsifier_direction` | string | yes | what observation would flip this verdict |
| `seed`, `python_version`, `generator_sha256` | — | yes | determinism (WP0.4) |

Schema bump is a separate commit `B15-SURF: schema certificate_v2` with a migration note; v1 certificates remain valid and are not rewritten.

---

## 6. Ledger and atlas rules for this sprint

- All B15 results are filed on the **mathematics / benchmark ledger**, not the constant-block atlas. Rationale: hidden zeros are theory-internal identities that are effectively unobservable; the surfaceology report's own caveat is that a shared-fingerprint equivalence is a low-*measurement*-warrant statement even when its *mathematical* warrant is E0. The two axes must not be conflated.
- No entry in `claims-table.md` changes. If the agent believes a B15 result bears on an atlas cell, it files an open item (§9) and stops.
- The three-layer no-circularity rule applies: success in reproducing surfaceology at the DOMAIN layer is not evidence for the UNIVERSAL-layer conjecture that 𝕽 exists. The sprint report must say this in its first paragraph.

---

## 7. Pre-registration (`docs/sprints/B15-SURF/prereg-002.md`)

Written and committed **before** the first certified run; its commit hash is recorded in every B15 certificate under `prereg_ref`. Contents:

1. **POS** — target bound (equation, normalization, conventions); registered inside/outside test points; bisection ray and ray endpoints; bracket-width threshold (proposal: `1/2^20` in the bound's natural units — Erick to confirm); negative-control perturbation.
2. **ZERO** — index conventions; list of admissible splits per n; number of random rational points per test (≥ 200 for route agreement; ≥ 50 for splits); "generically nonzero" threshold (≥ 95% of random-constraint points); δ-shift prefactor and limit as transcribed; NLSM ground-truth source.
3. **GID** — fingerprint schema version; relabeling group; similarity/confidence thresholds for Outcome A (proposal: both ≥ 9/10 as exact rationals — Erick to confirm); held-out multiplicity (n=8); the two pre-registered outcomes and the `NONIDENTIFIABLE` fallback.
4. **Falsifiers** — the four registered in §8.
5. **Stop rules** — what halts the sprint (WP1 route disagreement; WP2 route disagreement; schema validation failure in CI).

Thresholds above are *proposals*; per program rule they must be data-calibrated where a calibration route exists, and the calibration route must be stated in the prereg.

---

## 8. Registered falsifiers

| ID | Statement | Consequence if triggered |
|---|---|---|
| F1 | B15-POS bracket excludes the published bound value | Exact-PSD machinery `REJECTED` for external bounds; all downstream PERMITTED/EXCLUDED claims in the program become `CONDITIONAL(B15-POS)` until resolved |
| F2 | Routes A and B disagree at any registered point | Amplitude generator `REJECTED`; dataset not shipped |
| F3 | Hidden zeros fail to vanish exactly on any registered split | Either transcription error (erratum, re-transcribe) or a real discrepancy with the source (file as open item, do not "fix" numerically) |
| F4 | GID separates at n≤6 but not n=8 | `fingerprint_v1` `REJECTED` as over-fit |

---

## 9. Open items requiring Erick's decision (agent must not resolve unilaterally)

- **OI-1** Confirm the exact EFT-hedron target bound for B15-POS once the agent proposes it from arXiv:2012.15849.
- **OI-2** Confirm the two proposed thresholds in §7 (bracket width; GID similarity/confidence) or supply calibration routes.
- **OI-3** Whether WP2.8 (YM-scaffolded) is required or stretch for this sprint.
- **OI-4** Whether to open B16 on the constraint-manifest representation (WP4 output).
- **OI-5** Whether `ground_truth_route: null` certificates (i.e. all pre-B15 atlas-bearing certificates) should be flagged in the ledger with a standing note about the ground-truth disanalogy. Recommendation: yes, as a schema-level annotation, no verdict changes.
- **OI-6** Naming: "MnemoryOS" vs "MnemesisOS" remains an unresolved discrepancy from the Ghidra package; this sprint uses "MnemesisOS" and touches no transfer docs.
- **OI-7** The two standing DRAFT items (CONDITIONAL(X) §6 extension; B*→M* relabeling) are still pending; B15 files under the current vocabulary and uses B* IDs.

---

## 10. Backlog (recorded, not scheduled)

- ML conjecture generation: symbolic regression (PySR-style, numeric→symbolic) over `zero_dataset_v1` as a *conjecture source only*; every proposal must pass `verify_certificate.py` or be filed `REJECTED`/`NONIDENTIFIABLE`. Precedent: arXiv:2408.04720 (transformer compression, rediscovery), arXiv:2602.15169 (PySR rediscovery of KLT/BCJ to 5 points), arXiv:2602.12176 (AI-conjectured, human-proved single-minus gluon result; narrow kinematic slice).
- Loop-level hidden zeros / 2-splits (arXiv:2604.13810) once tree-level benchmarks are green.
- Cosmological-wavefunction zeros (arXiv:2503.23579) as a second domain for the "≥2 domains" promotion rule.
- MnemesisOS transfer of the candidate-forest store (Ghidra A4) — separate session per Erick's stated intent.

---

## 11. Definition of done

- `python3 tools/run_all_certified.py` green: 22 legacy suites + `test_b15_pos`, `test_b15_zero`, `test_b15_gid`; committed baseline.
- All B15 certificates validate against `certificate_v2` and pass `tools/verify_certificate.py` standalone.
- `prereg-002.md` committed before first certified run; its hash appears in every certificate.
- `sprint-report.md` with: verdicts per WP, which GID outcome obtained, redundancy metrics, errata filed, open items list (§9) reproduced with status.
- `reconciliation.md` mapping every §4 target to its actual path.
- Sprint zip(s) under 25 MB each, live tree in part1.

---

## 12. References (primary)

- Arkani-Hamed, Frost, Salvatori, Plamondon, Thomas — *All Loop Scattering As A Counting Problem*, arXiv:2309.15913; *All Loop Scattering For All Multiplicity*, arXiv:2311.09284.
- Arkani-Hamed, Cao, Dong, Figueiredo, He — *Hidden zeros for particle/string amplitudes and the unity of colored scalars, pions and gluons*, arXiv:2312.16282.
- Arkani-Hamed, Cao, Dong, Figueiredo, He — *NLSM ⊂ Tr(φ³)*, arXiv:2401.05483.
- Arkani-Hamed, Cao, Dong, Figueiredo, He — *Scalar-Scaffolded Gluons and the Combinatorial Origins of Yang-Mills Theory*, arXiv:2401.00041.
- Arkani-Hamed, Figueiredo — *All-order splits and multi-soft limits for particle and string amplitudes*, arXiv:2405.09608.
- Arkani-Hamed, Bai, He, Yan — *Scattering Forms and the Positive Geometry of Kinematics, Color and the Worldsheet*, arXiv:1711.09102.
- Arkani-Hamed, Huang, Huang — *The EFT-Hedron*, arXiv:2012.15849.
- Simmons-Duffin — *A Semidefinite Program Solver for the Conformal Bootstrap*, arXiv:1502.02033 (certificate-structure reference only; not a dependency).
- Internal: SPECIFICATION.md v1.0; PIR Foundation Package v2 (FINAL_ANALYSIS.md); surfaceology deep-research report (2026-09-21).

All arXiv IDs above were verified in the 2026-09-21 research pass; the agent re-checks each ID at transcription time and records any discrepancy as an erratum.
